from typing import Final

GITHUB_PROFILE_SIZE: Final = (500, 500)  # NOTE - This to be implemented later
LINKEDIN_PROFILE_SIZE: Final = (400, 400)  # NOTE - This to be implemented later
LINKEDIN_COVER_SIZE: Final = (1400, 350)  # NOTE - Keeping the aspect ratio of 4:1

LOGO_SIZE: Final = (25, 25)
