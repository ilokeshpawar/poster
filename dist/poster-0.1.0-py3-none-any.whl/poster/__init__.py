from beartype.claw import beartype_this_package

beartype_this_package()
